<?php

// Change database host, database name, username and user password
define("_DATABASE_HOST", "localhost");
define("_DATABASE_NAME", "panel_panel"); 
define("_DATABASE_USER_NAME", "panel_panel");
define("_DATABASE_PASSWORD", "pfout.08");

define("_DB_PREFIX", "pf_");

?>