<? 
include_once($_SERVER['DOCUMENT_ROOT'].'/classes/defineThis.php');
$base = PANELDB; 
$server = PANELDBHOST; 
$user = PANELDBUSER;
$pass = PANELDBPASS; 

?>