<? if (($_GET['tab'] == 'feed') || ($_GET['s'] == 'feed')) {?>
                             <img src="http://www.wevolt.com/images/feed_header.png" />
<? }?>

             
        
       
    