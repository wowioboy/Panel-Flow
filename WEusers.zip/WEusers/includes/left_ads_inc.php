<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style type="text/css">
body,html {
padding:0px;
margin:0px;

}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
<script language=javascript src="http://ads.addynamix.com/creative/2-2127755-2j?"></script>
<noscript language=javascript><a href="http://ads.addynamix.com/click/2-2127755-2"><img src="http://ads.addynamix.com/creative/2-2127755-2" border=0></a></noscript>
<?php /*
<? if ($_GET['home'] == 1) {?>
<!-- AD TAG BEGINS: WeVolt(gr.wevolt) / homepage / 300x250,300x600 -->
<script type="text/javascript">
	var gr_ads_zone = 'homepage';
	var gr_ads_size = '300x250,300x600';
</script>
<script type="text/javascript" src="http://a.giantrealm.com/gr.wevolt/a.js">
</script>
<noscript>
	<a href="http://ans.giantrealm.com/click/gr.wevolt/homepage;tile=2;sz=300x250;ord=1234567890">
		<img src="http://ans.giantrealm.com/img/gr.wevolt/homepage;tile=2;sz=300x250;ord=1234567890" width="300" height="250" alt="advertisement" />
	</a>
</noscript>
<!-- AD TAG ENDS: WeVolt / homepage / 300x250,300x600 -->

<? } else {?>
<!-- AD TAG BEGINS: WeVolt(gr.wevolt) / ros / 300x250,300x600 -->
<script type="text/javascript">
	var gr_ads_zone = 'ros';
	var gr_ads_size = '300x250,300x600';
</script>
<script type="text/javascript" src="http://a.giantrealm.com/gr.wevolt/a.js">
</script>
<noscript>
	<a href="http://ans.giantrealm.com/click/gr.wevolt/ros;tile=2;sz=300x250;ord=1234567890">
		<img src="http://ans.giantrealm.com/img/gr.wevolt/ros;tile=2;sz=300x250;ord=1234567890" width="300" height="250" alt="advertisement" />
	</a>
</noscript>
<!-- AD TAG ENDS: WeVolt / ros / 300x250,300x600 -->
<? }?>
*/ ?>
</body>
</html>
