<? 
$IncludesDirectory = '/var/www/vhosts/w3volt.com/httpdocs/';
$api_key = 'fb41073237b0062c77129093afd152fd';
$secret = '2c6b22309852be72fcf3528c1648c407';

?>