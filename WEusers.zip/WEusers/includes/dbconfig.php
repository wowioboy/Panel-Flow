<?php $userhost = 'localhost';
$userdb = 'panel_panel';
$usertable = 'users';
$userpass = 'pfout.08';
$dbuser =  'panel_panel';
$commenttable = 'usercomments';
$comicstable = 'comics';
$userstable = 'users';
$favtable = "favorites";
?>