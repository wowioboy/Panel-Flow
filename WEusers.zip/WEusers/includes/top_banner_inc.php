<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<style type="text/css">
body,html {
padding:0px;
margin:0px;

}

</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<body>
<script language=javascript src="http://ads.addynamix.com/creative/2-2127755-1j?"></script>
<noscript language=javascript><a href="http://ads.addynamix.com/click/2-2127755-1"><img src="http://ads.addynamix.com/creative/2-2127755-1" border=0></a></noscript>
<?php /*
<!-- AD TAG BEGINS: BarkIt(gr.barkit) / homepage / 300x250,300x600 -->
<? if ($_GET['home'] == 1) {?>
<!-- AD TAG BEGINS: WeVolt(gr.wevolt) / homepage / 728x90 -->
<script type="text/javascript">
	var gr_ads_zone = 'homepage';
	var gr_ads_size = '728x90';
</script>
<script type="text/javascript" src="http://a.giantrealm.com/gr.wevolt/a.js">
</script>
<noscript>
	<a href="http://ans.giantrealm.com/click/gr.wevolt/homepage;tile=1;sz=728x90;ord=1234567890">
		<img src="http://ans.giantrealm.com/img/gr.wevolt/homepage;tile=1;sz=728x90;ord=1234567890" width="728" height="90" alt="advertisement" />
	</a>
</noscript>
<!-- AD TAG ENDS: WeVolt / homepage / 728x90 -->
<? } else {?>
<!-- AD TAG BEGINS: WeVolt(gr.wevolt) / ros / 728x90 -->
<script type="text/javascript">
	var gr_ads_zone = 'ros';
	var gr_ads_size = '728x90';
</script>
<script type="text/javascript" src="http://a.giantrealm.com/gr.wevolt/a.js">
</script>
<noscript>
	<a href="http://ans.giantrealm.com/click/gr.wevolt/ros;tile=1;sz=728x90;ord=1234567890">
		<img src="http://ans.giantrealm.com/img/gr.wevolt/ros;tile=1;sz=728x90;ord=1234567890" width="728" height="90" alt="advertisement" />
	</a>
</noscript>
<!-- AD TAG ENDS: WeVolt / ros / 728x90 -->

<? }?>
*/ ?>
</body>
</html>
