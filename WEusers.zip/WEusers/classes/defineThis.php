<?php 
define("VERSION", "2.0");
define("INCLUDES", $_SERVER['DOCUMENT_ROOT'].'/includes/');
define("FUNCTIONS", $_SERVER['DOCUMENT_ROOT'].'/functions/');
define("CLASSES", $_SERVER['DOCUMENT_ROOT'].'/classes/');
define("DOCPATH", realpath(dirname(__FILE__)) . '/');
define("ANALYTICSDB", "panel_analytics");
define("PFENGINEDIR", "panelflow");
define("PFADMINDIR", "pf_16_core");

define("PANELDBHOST", "72.167.245.143");
define("PANELDB", "panel_panel");
define("PANELDBUSER", "wevolt");
define("PANELDBPASS", "wX4eY.xUDaFHZxEY");