<?  
include 'includes/init.php'; 
include 'includes/comic_functions.php'; 
include 'includes/admin_date_inc.php'; 
$BGcolor = substr($MovieColor, 2, 6); 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="scripts/swfobject.js"></script>
<meta name="description" content="<?php echo $Synopsis ?>"></meta>
<meta name="keywords" content="<?php echo $Genre;?>, <?php echo $Tags;?>"></meta>
<LINK href="css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $ComicTitle; ?> - ADMIN SECTION</title>
</head>
<body background="images/admin_bg.jpg"  style="background-repeat:repeat-x;">
<div class="wrapper" align="center">
<?php if ($_SESSION['usertype'] == 1){?>
<div id="admin">To listen this track, you will need to have Javascript turned on and have <a href="http://www.adobe.com/go/getflashplayer/" target="_blank">Flash Player 8</a> or better installed.</div>
			    <script type="text/javascript"> 
                  var so = new SWFObject('flash/pf_admin_standard_v1-4d.swf','mpl','1024','728','9'); 
                  so.addParam('allowfullscreen','true'); 
                  so.addParam('allowscriptaccess','true'); 
  				  so.addVariable('usertype','<?php echo $_SESSION['usertype'];?>');
				  so.addVariable('barcolor','<?php echo $BarColor;?>');
				  so.addVariable('textcolor','<?php echo $TextColor;?>');
				  so.addVariable('moviecolor','<?php echo $MovieColor;?>');
				  so.addVariable('buttoncolor','<?php echo $ButtonColor;?>');
				  so.addVariable('arrowcolor','<?php echo $ArrowColor;?>');
				  so.addVariable('baseurl','<?php echo $_SERVER['HTTP_HOST'];?>');
				  so.addVariable('userid','<?php echo $_SESSION['userid'];?>');
				  so.addVariable('currentday','<?php echo $CurrentDay;?>');
				  so.addVariable('currentmonth','<?php echo $CurrentMonth;?>');
				  so.addVariable('currentyear','<?php echo $CurrentYear;?>');
				  so.addVariable('avatar','<?php echo $Avatar;?>');
				  so.addVariable('comicurl','<?php echo $ComicURL;?>');
                  so.write('admin'); 
                </script>
				<? }  else {?>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div> YOU NEED TO LOG IN AS AN ADMINISTRATOR TO ACCESS THE ADMIN PANEL</div>
				<div> <a href="login.php">CLICK HERE</a> </div>
					<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<div class="spacer"></div>
				<?php }?>

				<div class="spacer"></div>
				
  <div class="contentwrapper" align="center"></div>			
</div>		
</body>
</html>
