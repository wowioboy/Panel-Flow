<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<LINK href="http://www.panelflow.com/css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PANEL FLOW - NO CONFIG FILE</title>
</head>

<body>
<?php include 'includes/header.php'; ?>

<div align="center" style="padding:15px;"> It appears this comic has not been fully installed or the config file is missing. Please re-install the application to restore the site. </div>

<?php include 'includes/footer.php'; ?>