<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php if($styles) echo $styles; ?>

<?php if($scripts) echo $scripts; ?>
<LINK href="http://www.panelflow.com/css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PANEL FLOW - AVATAR CREATOR</title>
</head>

<body>
<div class="wrapper" align="center">

<table width="534" cellpadding="0" cellspacing="0" border="0"><tr>
<td background="http://www.panelflow.com/images/content_bg.gif" id="contentcell" style="background-repeat:repeat-y;"><div class="spacer"></div><div class="spacer"></div><div class="logo"><a href="http://www.panelflow.com/" target="blank"><img src="http://www.panelflow.com/images/logo.jpg" border="0" /></a></div><div class="slug" align="right">THE FLASH <font color="#ffa66d">WEBCOMIC</font><br />CONTENT MANAGEMENT SYSTEM</div></td>
</tr>
  <tr>
    <td background="http://www.panelflow.com/images/content_bg.gif" id="contentcell" valign="top" style="background-repeat:repeat-y;">
	<div class="spacer"></div>
</td>
  </tr>
  <tr>
    <td height="30" background="http://www.panelflow.com/images/content_footer.gif" style="background-repeat:no-repeat"></td>
  </tr>
</table>
				
<div class="spacer"></div>		

</div>		


