<?php require("install_functions.php"); 
$ID = $_POST['id'];
$Version = '1-4';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="http://www.panelflow.com/lib/prototype.js"></script>
<script type="text/javascript" src="http://www.panelflow.com/lib/scriptaculous.js"></script>
<script type="text/javascript" src="http://www.panelflow.com/lib/init_wait.js"></script>
<script type="text/javascript" src="http://www.panelflow.com/scripts/swfobject.js"></script>
<meta name="description" content="Flash Web Comic Content Management System"></meta>
<meta name="keywords" content="Webcomics, Comics, Flash"></meta>
<LINK href="http://www.panelflow.com/css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PANEL FLOW - INSTALL </title>
</head>
<body>
<?php include 'includes/header.php';?>
<?php 
$usercreated =$_POST['usercreated']; 
$configcreated = $_POST['configcreated']; 
if (!isset($_POST['email']) && ($usercreated != 1)) {
     // Show the form
      include 'install_user_inc.php';
	  include 'includes/footer.php';
     exit;
} else {
if ($usercreated != 1){

$logresult = file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=logincrypt&email='.$_POST['email'].'&pass='.md5($_POST['userpass']));
     if (trim($logresult) == 'Not Logged') {
	     print "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>There was an error logging into your account. Please check your login information and try again. If you've forgotten your Panel Flow Account information. <a href='http://www.panelflow.com/forgotaccount.php'>CLICK HERE</a></b><div class='spacer'></div> <div class='spacer'></div></div>";
		 include 'install_user_inc.php';
		 include 'includes/footer.php';
		 exit;
      }  else if (trim($logresult) == 'Not Verified'){
	  
	     print "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>Your account has not yet been verified. </b>You must verify your account before you can create a comic. <div class='spacer'></div> To Verify your account please click on the link we sent to the email you registered with. If you did not recieve an email please go to <a href='http://www.panelflow.com/resend.php' target='blank'> www.panelflow.com/resend.php </a><div class='spacer'></div> If you are having problems recieving your account verification email, check your junk folder or email: accounts@panelflow.com <div class='spacer'></div> After you're verified, please run this install script again to begin your comic.<div class='spacer'></div></div>";
		  include 'includes/footer.php';
	      
	  } else {  
		  
		    $ID = trim($logresult);
			$file_to_write = 'tempconfig.php';
			$content = "<?php \n$";
			$content .= "username ='".$_POST['username']."';\n";
			$content .= "$";
			$content .= "email='".$_POST['email']."';\n";
			$content .= "$";
			$content .= "userid ='".$ID."';\n";
			$content .= "?>";
			$fp = fopen($file_to_write, 'w');
			fwrite($fp, $content);
			fclose($fp);
			$profileresult = file_get_contents ('http://www.panelflow.com/processing/getprofile.php?userid='.$ID);
			$values = unserialize ($profileresult);
			
			$file_to_write = 'creatorXML.xml';
			$content ="<creatorinfo><creator>";
			$content .="<creatorname>".$values['username']."</creatorname>";
			$content .="<myfavs>".$values['influences']."</myfavs>";
			$content .="<bio>".$values['about']."</bio>";
			$content .="<myfavs>".$values['influences']."</myfavs>";
			$content .="<location>".$values['location']."</location>";
			$content .="<hobbies>".$values['hobbies']."</hobbies>";
			$content .="<website>".$values['website']."</website>";
			$content .="<link1>".$values['link1']."</link1>";
			$content .="<link2>".$values['link2']."</link2>";
			$content .="<link3>".$values['link3']."</link3>";
			$content .="<link4>".$values['link4']."</link4>";
			$content .="<music>".$values['music']."</music>";
			$content .="<credits>".$values['credits']."</credits>";
			$content .="<books>".$values['books']."</books>";
			$content .="<avatar>".$values['avatar']."</avatar>";
			$content .="</creator></creatorinfo>";
			$fp = fopen($file_to_write, 'w');
			fwrite($fp, $content);
			fclose($fp);
			rename($file_to_write, '../xml/creatorXML.xml');
			chmod('../xml/creatorXML.xml', 0755);
			include 'comic_form_inc.php';
		    include 'includes/footer.php';
	  }// Close Login result check 

}  else if (($configcreated == 1) && ($usercreated == 1)) {
   if (($_POST['comictitle'] == "") || ($_POST['comicurl'] == "")) {
     // Show the form
	  echo "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>You must enter information for both the Comic Title and Comic Url (this is how your comic listing will sync up to the comic syndication database.</div></b>";
      include 'comic_form_inc.php';
	  include 'includes/footer.php';
     exit;
} else {

$UrlCheck = $_POST['comicurl'];
$slashcheck = $UrlCheck{strlen($UrlCheck)-1};
$FrontCheck = substr($UrlCheck, 0, 7);
if ($slashcheck == '/') {
 echo "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>Please do not add the trailing slash '/' onto your comic url.</div></b>";
      include 'comic_form_inc.php';
	  include 'includes/footer.php';
	  exit;

} else if ($FrontCheck != 'http://') {
echo "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>Please include the 'http://' to the front of your url.</div></b>";
      include 'comic_form_inc.php';
	  include 'includes/footer.php';
	  exit;
}

$Genres = "";
for ($i=1; $i< 17; $i++){
 if (isset($_POST['g'.$i])){
 if ($Genres != "" ) {
 $Genres .=", ";
 }
$Genres .= $_POST['g'.$i];
}
}

	$comicresult = file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=comic&comictitle='.urlencode($_POST['comictitle']).'&comicurl='.urlencode($_POST['comicurl'])."&version=".$Version."&id=".$_POST['id'].'&genres='.urlencode(trim($Genres)));
	if ((trim($comicresult) != 'Comic Exists') && (trim($comicresult) != 'Url Exists') && (trim($comicresult) != 'Not Found')) {
			$file_to_write = 'infoXML_temp.php';
			$content = "<?php \n$";
			$content .= "comicid ='".trim($comicresult)."';\n";
			$content .= "$";
			$content .= "comictitle ='".trim($comictitle)."';\n";
			$content .= "$";
			$content .= "comicurl ='".$comicurl."';\n";
			$content .= "$";
			$content .= "creator ='".$creator."';\n";
			$content .= "$";
			$content .= "writer ='".$writer."';\n";
			$content .= "$";
			$content .= "artist ='".$artist."';\n";
			$content .= "$";
			$content .= "synopsis ='".$synopsis."';\n";
			$content .= "$";
			$content .= "genres ='".$Genres."';\n";
			$content .= "?>";
			$fp = fopen($file_to_write, 'w');
			fwrite($fp, $content);
			fclose($fp);
			
			include 'tempconfig.php';
	        $file_to_write = 'config.php';
			$content ="<?php \n";
			$content .="\$config['comicid'] = '".trim($comicresult)."';\n";
			$content .="\$config['username'] = '".$username."';\n";
			$content .="\$config['email'] = '".$email."';\n";
			$content .="\$config['userid'] = '".$userid."';\n";
			$content .="\$config['comicurl'] = '".$_POST['comicurl']."';\n";
			$content .="?>";
			$fp = fopen($file_to_write, 'w');
			fwrite($fp, $content);
			fclose($fp);
			rename($file_to_write, '../includes/config.php');
			chmod('../includes/config.php', 0644);
			$makecreator= file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=makecreator&id='.trim($_POST['id']));
			
        include 'crop_form_inc.php';
		include 'includes/footer.php';
} else if (trim($comicresult) == 'Comic Exists') {
			  echo "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>That comic name is already taken. Please select a new Title.</div></b>";
      include 'comic_form_inc.php';
	  include 'includes/footer.php';
     exit;
 } else if (trim($comicresult) == 'Url Exists') {
			  echo "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>That URL is already in use with another comic. You can host multiple comics on the same domain, but you must place each instance in it's seperate directory and use the full URL including directory as the path, for instance <br/> http://www.mydomain.com/comicdirectory</div></b>";
      include 'comic_form_inc.php';
	  include 'includes/footer.php';
     exit;
 } else if (trim($comicresult) == 'Not Found'){
echo "<div class='errormsg'><div class='spacer'></div> <div class='spacer'></div><b>There was an error connecting to your comic server, please make sure you have the full path including the subfolders to where the Panel Flow install exists.</div></b>";
      include 'comic_form_inc.php';
	  include 'includes/footer.php';
	  exit;
}
			
}		
			
} // Comic Information Else 

} // End Main Else
?>

</body>
</html>
