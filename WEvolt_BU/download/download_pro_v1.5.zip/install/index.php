<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="http://www.panelflow.com/scripts/swfobject.js"></script>
<meta name="description" content="Flash Web Comic Content Management System"></meta>
<meta name="keywords" content="Webcomics, Comics, Flash"></meta>
<LINK href="http://www.panelflow.com/css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PANEL FLOW - INSTALL </title>
</head>
<body>
<?php include 'includes/header.php';?>
<div class="featuresheader">CMS FEATURES</div>
<div class="featurelist"> <ul>
          <li class="bullet">Cue Pages to release on a specific date
    <li class="bullet">Easily edit, add, delete and move pages.
    <li class="bullet">Customize the colors, add a banner, edit META tags and comic information.
    <li class="bullet">Allow readers to register, comment and track your comic.
    <li class="bullet">Promote other comics through a simple link sharing module.
    <li class="bullet">Use the PANEL FLOW syndicator to post your comic on other webhosts and have it always display the latest update and will click the user to your site to read the archives.
    </ul>
			<div align="center">
			  <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="240" height="90" id="install_btn" align="middle">
			    <param name="allowScriptAccess" value="sameDomain" />
			    <param name="movie" value="install_btn.swf" />
			    <param name="quality" value="high" />
			    <param name="bgcolor" value="#ffffff" />
			    <embed src="install_btn.swf" quality="high" bgcolor="#ffffff" width="240" height="90" name="install_btn" align="middle" allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />          
			    </embed>
		        </object>
        </div>
	</div>
	  
	  
	  
	  
	  <?php include 'includes/footer.php';?>
</body>
</html>
