<?  
include_once("includes/init.php");
include 'includes/comic_functions.php';
 $BGcolor = substr($MovieColor, 2, 6); 
 
 if ($ContactSetting == 0) {
 header("Location:/index.php");
 }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<script type="text/javascript" src="scripts/swfobject.js"></script>
<meta name="description" content="<?php echo $Synopsis ?>"></meta>
<meta name="keywords" content="<?php echo $Genre;?>, <?php echo $Tags;?>"></meta>
<LINK href="css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title><?php echo $ComicTitle; ?> - <?php echo $CreatorName; ?></title>


</head>

<body bgcolor="<?php echo '#'.$BGcolor;?>">

<div class="wrapper" align="center">

<div class="header"><img src="<?php echo $HeaderImage;?>" /></div>
<?php include 'includes/topbar_inc.php'; ?>
</div>

<div class="spacer"></div>
<div align="center">
<div class="spacer"></div>
<div class="contentwrapper" align="center">
<table cellpadding="0" cellspacing="0" border="0">
	<tr>
	<td width="489" valign="top">
	<div class="rightwrapper">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" valign="top">
		<div id="email">You need to have your javascript turned on and make sure you have the latest version of Flash<a href="http://www.adobe.com/go/getflashplayer/" target="_blank">Player 9</a> or better installed.</div>

<script type="text/javascript"> 
    var so = new SWFObject('flash/email.swf','email','437','239','9');             
				  so.addParam('allowfullscreen','true'); 
                  so.addParam('allowscriptaccess','true'); 
                  so.write('email'); 
</script>		
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
</div>
</td>
    </tr>
</table>
</div>
</div>

	
</body>
</html>
