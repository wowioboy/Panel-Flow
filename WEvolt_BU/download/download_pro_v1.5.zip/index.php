<?  
if (!file_exists('includes/config.php')) {
if (!file_exists('install/index.php')) {
     header('Location: /noconfig.php');
	 } else {
	 
	 header('Location: install/index.php');
	 }
   // echo "The file $filename exists";
}	
include_once("includes/init.php");
$Pagetracking = 'Home'; 
include_once("includes/comic_functions.php"); 
$BGcolor = substr($MovieColor, 2, 6);  
?>

<?php include 'includes/comic_header.php'; ?>

<?php 
//PAGE DISPLAY
include 'includes/reader_inc.php'; 
?>
				
<div class="spacer"></div>	
<div class="contentwrapper" align="center">

<table width="799">
<tr>
<td width="423" height="229" valign="top">
	
<!-- AUTHOR COMMENT MODULE -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop"></td>
	<td id="modtopright"></td>
</tr>
	
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	<?php 
	// Page Comments Module
	include 'includes/author_comment_module.php'; 
	?>	
	</td>
	<td id="modrightside"></td>
</tr>
	
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->

<? if ($CommentSetting == 1) { ?>
<!-- PAGE COMMENT MODULE -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop"></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	<?php 
	// Page Comments Module
	include 'includes/page_comments_module.php'; 
	?>	
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->		
<? } ?>

</td>	
<!-- END OF LEFT COLUM  -->		
<td width="20">&nbsp;</td>		
<td width="340" valign="top">

<!-- USER CONTROL MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">				
	<?php 
	// Login Module //
	include 'includes/user_module.php'; 
	?>	
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td  id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->
		

<!-- COMIC INFO MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	<?php 
	// Login Module //
	include 'includes/comic_module.php'; 
	?>	
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->

<!-- COMIC SYNOPSIS MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	<?php 
	// Synopsis Module // 
	include 'includes/comic_synopsis_module.php'; ?>					
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->

<? if ($CommentSetting == 1) { ?>
<!-- COMMENT FORM MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td id="modtop"></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	<?php 
	// Login Module
	include 'includes/comment_module.php'; 
	?>				
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->
<? } ?>

<!-- USER LOGIN MODULE  -->

	<?php 
	// Login Module
	include 'includes/login_inc.php'; 
	?>	
	
<!-- END MODULE  -->
		
</td>
</tr>
</table>
</div>			
<?php include 'includes/comic_footer.php'; ?>	