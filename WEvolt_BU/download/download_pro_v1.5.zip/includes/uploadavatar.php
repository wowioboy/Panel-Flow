<?php
include 'init.php';
$Avatar = $_GET['avatar'];
$ID = $_GET['userid'];
$result = file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=avatar&id='.$ID.'&avatar=http://'.$_SERVER['SERVER_NAME'].'/images/'.$Avatar);

?>