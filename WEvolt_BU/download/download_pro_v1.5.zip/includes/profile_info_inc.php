<?php if (isset($Bio)) { ?>
<table width="367" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td  background="images/profile_top_left.png" width="12" height="13" style="background-repeat:no-repeat;"></td>
    <td width="331" height="13" background="images/profile_top.png" style="background-repeat:repeat-x;" ><div class="modheader">BIO: </div></td>
    <td background="images/profile_top_right.png" width="24" height="13"  style="background-repeat:no-repeat;"></td>
  </tr>
  <tr>
    <td width="12" background="images/profile_left_side.png" style="background-repeat:repeat-y;"></td>
    <td class="content"  width="201"valign="top" style="background-color:#FFFFFF;"><div class="modtext" style="padding:5px;"><?php echo $Bio; ?></div></td>
    <td background="images/profile_side.jpg"  style="background-repeat:repeat-y;" width="24"></td>
  </tr>
  <tr>
    <td height="10" colspan="3"  background="images/profile_bottom.png" style="background-repeat:repeat-x;"></td>
    </tr>
</table>
<?php } ?>

<?php if (isset($CreatorInfluence)) { ?>

<table width="367" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  background="images/profile_top_left.png" width="12" height="13" style="background-repeat:no-repeat;"></td>
    <td width="331" height="13" background="images/profile_top.png" style="background-repeat:repeat-x;" ><div class="modheader">INFLUENCES: </div></td>
    <td background="images/profile_top_right.png" width="24" height="13"  style="background-repeat:no-repeat;"></td>
  </tr>
  <tr>
    <td width="12" background="images/profile_left_side.png" style="background-repeat:repeat-y;"></td>
    <td class="content"  width="201"valign="top" style="background-color:#FFFFFF;"><div class="modtext" style="padding:5px;"><div class="modtext" style="padding:5px;"><?php echo $CreatorInfluence; ?></div></td>
    <td background="images/profile_side.jpg"  style="background-repeat:repeat-y;" width="24"></td>
  </tr>
  <tr>
    <td height="10" colspan="3"  background="images/profile_bottom.png" style="background-repeat:repeat-x;"></td>
    </tr>
</table>
<?php } ?>

<?php if (isset($OtherCredits)) { ?>
    <table width="367" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td  background="images/profile_top_left.png" width="12" height="13" style="background-repeat:no-repeat;"></td>
        <td width="331" height="13" background="images/profile_top.png" style="background-repeat:repeat-x;" ><div class="modheader">OTHER CREDITS: </div></td>
        <td background="images/profile_top_right.png" width="24" height="13"  style="background-repeat:no-repeat;"></td>
      </tr>
      <tr>
        <td width="12" background="images/profile_left_side.png" style="background-repeat:repeat-y;"></td>
        <td class="content"  width="201"valign="top" style="background-color:#FFFFFF;"><div class="modtext" style="padding:5px;">
          <div class="modtext" style="padding:5px;"><?php echo $OtherCredits; ?></div>
        </div></td>
        <td background="images/profile_side.jpg"  style="background-repeat:repeat-y;" width="24"></td>
      </tr>
      <tr>
        <td height="10" colspan="3"  background="images/profile_bottom.png" style="background-repeat:repeat-x;"></td>
      </tr>
    </table>
    <?php } ?>

<?php if (isset($Hobbies)) { ?>
<table width="367" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  background="images/profile_top_left.png" width="12" height="13" style="background-repeat:no-repeat;"></td>
    <td width="331" height="13" background="images/profile_top.png" style="background-repeat:repeat-x;" ><div class="modheader">HOBBIES: </div></td>
    <td background="images/profile_top_right.png" width="24" height="13"  style="background-repeat:no-repeat;"></td>
  </tr>
  <tr>
    <td width="12" background="images/profile_left_side.png" style="background-repeat:repeat-y;"></td>
    <td class="content"  width="201"valign="top" style="background-color:#FFFFFF;"><div class="modtext" style="padding:5px;"><div class="modtext" style="padding:5px;"><?php echo $Hobbies; ?></div></td>
    <td background="images/profile_side.jpg"  style="background-repeat:repeat-y;" width="24"></td>
  </tr>
  <tr>
    <td height="10" colspan="3"  background="images/profile_bottom.png" style="background-repeat:repeat-x;"></td>
    </tr>
</table>
<?php } ?>


<?php if (isset($Music)) { ?>
<table width="367" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  background="images/profile_top_left.png" width="12" height="13" style="background-repeat:no-repeat;"></td>
    <td width="331" height="13" background="images/profile_top.png" style="background-repeat:repeat-x;" ><div class="modheader">FAVORITE MUSIC: </div></td>
    <td background="images/profile_top_right.png" width="24" height="13"  style="background-repeat:no-repeat;"></td>
  </tr>
  <tr>
    <td width="12" background="images/profile_left_side.png" style="background-repeat:repeat-y;"></td>
    <td class="content"  width="201"valign="top" style="background-color:#FFFFFF;"><div class="modtext" style="padding:5px;"><div class="modtext" style="padding:5px;"><?php echo $Music; ?></div></td>
    <td background="images/profile_side.jpg"  style="background-repeat:repeat-y;" width="24"></td>
  </tr>
  <tr>
    <td height="10" colspan="3"  background="images/profile_bottom.png" style="background-repeat:repeat-x;"></td>
    </tr>
</table>
<?php } ?>

<?php if (isset($Books)) { ?>
<table width="367" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td  background="images/profile_top_left.png" width="12" height="13" style="background-repeat:no-repeat;"></td>
    <td width="331" height="13" background="images/profile_top.png" style="background-repeat:repeat-x;" ><div class="modheader">FAVORITE BOOKS: </div></td>
    <td background="images/profile_top_right.png" width="24" height="13"  style="background-repeat:no-repeat;"></td>
  </tr>
  <tr>
    <td width="12" background="images/profile_left_side.png" style="background-repeat:repeat-y;"></td>
    <td class="content"  width="201"valign="top" style="background-color:#FFFFFF;"><div class="modtext" style="padding:5px;"><div class="modtext" style="padding:5px;"><?php echo $Books; ?></div></td>
    <td background="images/profile_side.jpg"  style="background-repeat:repeat-y;" width="24"></td>
  </tr>
  <tr>
    <td height="10" colspan="3"  background="images/profile_bottom.png" style="background-repeat:repeat-x;"></td>
    </tr>
</table>
<?php } ?>