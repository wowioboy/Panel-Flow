<?php 
include_once("init.php"); 
   $xml_doc = stripslashes ($_POST['xmlString']);
    $default_dir =  $_POST['xmlFile'];
	$Action = $_POST['action'];
	$SelectedPage= $_POST['selectedpage'];
	$TotalPages= $_POST['totalpages'];		 
$backup1 = '../xmlbackup/01-'.$default_dir;
$backup2 = '../xmlbackup/02-'.$default_dir;
$backup3 = '../xmlbackup/03-'.$default_dir;
$backup4 = '../xmlbackup/04-'.$default_dir;
$backup5 = '../xmlbackup/05-'.$default_dir;
$xml_doc = str_replace(chr(13), '\n', $xml_doc);
$xml_doc = str_replace(chr(10), '\n', $xml_doc);
$fp = fopen("../xml/".$default_dir,'w');
$write = fwrite($fp,$xml_doc);
copy($backup4, $backup5);
copy($backup3, $backup4);
copy($backup2, $backup3);
copy($backup1, $backup2);
copy("../xml/".$default_dir, $backup1);
echo "&xmlcomplete=1";
?>