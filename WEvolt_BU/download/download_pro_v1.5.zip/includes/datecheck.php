<?php 
$UpdateXml = 0;
$CurrentDate= date('D M j'); 
$CurrentDay = date('d');
$CurrentMonth = date('m');
$CurrentYear = date('Y');

if ($PageID == ''){
	for ($z=$counter-1; $z>= 0; $z--){
		$Date = $story_array[$z]->datelive;
		$Active = $story_array[$z]->active;
		$PageDay = substr($Date, 3, 2); 
		$PageMonth = substr($Date, 0, 2); 
		$PageYear = substr($Date, 6, 4);

 			if ($Active == 1){
 				$PageID = $story_array[$z]->id;
 				$AuthorComment = $story_array[$z]->comment;
				$Image = $story_array[$z]->image;
				$Title = $story_array[$z]->title;
				$ImageHeight = $story_array[$z]->imgheight;	
				list($Width, $Height) = split('[x]', $ImageHeight);	
			$CurrentPageDay = $PageDay;
			$CurrentPageMonth = $PageMonth;
			$CurrentPageYear = $PageYear;	
	
 				$CurrentIndex = $z;
				$NextPage = $PageID;
				  if ($z > 0) {
				    $PrevPage = $story_array[$z-1]->id;
				    } else { 
					$PrevPage = $PageID;
					}
				break;
 			 }  else if ($PageYear<$CurrentYear) {
				  $PageID = $story_array[$z]->id;
 				  $AuthorComment = $story_array[$z]->comment;
				  $Image = $story_array[$z]->image;
				  $Title = $story_array[$z]->title;
				  $ImageHeight = $story_array[$z]->imgheight;
				  list($Width, $Height) = split('[x]', $ImageHeight);	
			$CurrentPageDay = $PageDay;
			$CurrentPageMonth = $PageMonth;
			$CurrentPageYear = $PageYear;		
 				  $CurrentIndex = $z;
				  $NextPage = $PageID;
				    if ($z > 0) {
				    $PrevPage = $story_array[$z-1]->id;
				    } else { 
					$PrevPage = $PageID;
					}
				  $UpdateXml = 1;
				  break;
			 } else if ($PageYear == $CurrentYear) {
				if ($PageMonth<$CurrentMonth) {
					$PageID = $story_array[$z]->id;
 				 	$AuthorComment = $story_array[$z]->comment;
				 	$Image = $story_array[$z]->image;
				  	$Title = $story_array[$z]->title;
					$ImageHeight = $story_array[$z]->imgheight;	
					list($Width, $Height) = split('[x]', $ImageHeight);
			$CurrentPageDay = $PageDay;
			$CurrentPageMonth = $PageMonth;
			$CurrentPageYear = $PageYear;	
 				  	$CurrentIndex = $z;
					$NextPage = $PageID;
			      	    if ($z > 0) {
				   		 $PrevPage = $story_array[$z-1]->id;
				    	} else { 
						$PrevPage = $PageID;
						}
				  	$UpdateXml = 1;
				  	break;
				} else if ($PageMonth == $CurrentMonth) {
					if ($PageDay<=$CurrentDay) {
						$PageID = $story_array[$z]->id;
 				 	    $AuthorComment = $story_array[$z]->comment;
				 	    $Image = $story_array[$z]->image;
				  	    $Title = $story_array[$z]->title;
						$ImageHeight = $story_array[$z]->imgheight;
						list($Width, $Height) = split('[x]', $ImageHeight);	
			$CurrentPageDay = $PageDay;
			$CurrentPageMonth = $PageMonth;
			$CurrentPageYear = $PageYear;	
 				  	    $CurrentIndex = $z;
						$NextPage = $PageID;
				        if ($z > 0) {
				   		 $PrevPage = $story_array[$z-1]->id;
				    	} else { 
						$PrevPage = $PageID;
						}
				  	    $UpdateXml = 1;
				  	    break;
			        } 
				}
			}
 	}  // end for
}else {
 for ($z=0; $z < $counter; $z++){
 		$Pagetest = $story_array[$z]->id;
 			if ($PageID == $Pagetest){
 			$AuthorComment = $story_array[$z]->comment;
			$Image = $story_array[$z]->image;
			$Title = $story_array[$z]->title;
			$ImageHeight = $story_array[$z]->imgheight;	
			list($Width, $Height) = split('[x]', $ImageHeight);
			$Date = $story_array[$z]->datelive;	
			$PageDay = substr($Date, 3, 2); 
			$PageMonth = substr($Date, 0, 2); 
			$PageYear = substr($Date, 6, 4);
			$CurrentPageDay = $PageDay;
			$CurrentPageMonth = $PageMonth;
			$CurrentPageYear = $PageYear;		
 			$CurrentIndex = $z;
			if ($z == ($counter - 1)){ 
			$NextPage = $PageID;
			} else if ($story_array[$z+1]->active == '1'){
			$NextPage = $story_array[$z+1]->id;
			} else {
			$NextPage = $PageID;
			}
			if ($z > 0) {
			$PrevPage = $story_array[$z-1]->id;
			} else { 
			$PrevPage = $PageID;
			}
 			break;
			}
 }
}
$ChapterCount = 1;
$ChapterPageCount = 1;
$PageCount = 1;
$Inchapter = 0;
$ChapterString = '<table cellspacing="0" cellpadding="0" border="0" width="100%"><tr><td valign="top">';
$boxString = '<form id="jumpbox" action="#" method="get">ARCHIVES<br/>
<select id="dropdown" style="width:100%;" name="url" onchange="window.location = this.options[this.selectedIndex].value; ">';
$TotalPages = 0;
for ($k=0; $k< $counter; $k++){
$idSafe = 0; 
 	$TestDate = $story_array[$k]->datelive;
	$Active = $story_array[$k]->active;
	$SafeID = $story_array[$k]->id;
	$PageDay = substr($TestDate, 3, 2); 
	$PageMonth = substr($TestDate, 0, 2); 
	$PageYear = substr($TestDate, 6, 4);
		if ($PageYear<$CurrentYear) {
			$idSafe = 1; 
			$TotalPages++;
			if ($story_array[$k]->chapter == 1) {
			   if ($Inchapter == 1) {
			  	 $ChapterPageCount = 1;
			   }
			$boxString .= "<option style='background-color:#f6ecea;' value='index.php?id=".$story_array[$k]->id."' ";
			if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			
			$boxString .= "><b>CHAPTER</b>".$ChapterCount." - ".$story_array[$k]->title."</option>";
			$ChapterString .= "<div class='chapterlinks'><b>CHAPTER ".$ChapterCount."</b><br /><a href='index.php?id=".$story_array[$k]->id."'>".$story_array[$k]->title."</a><div class='smspacer'></div>";

			$Inchapter = 1;
			$ChapterCount++;
			} else {
			 if ($Inchapter == 1) {
			$boxString .= "<option value='index.php?id=".$story_array[$k]->id."'";
			if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			$boxString .= ">&nbsp;&nbsp;&nbsp;Page ".$ChapterPageCount." - ".$story_array[$k]->title."</option>";
			$ChapterString .= "<div class='chapterlinks'><b>CHAPTER ".$ChapterCount."</b><br /><a href='index.php?id=".$story_array[$k]->id."'>".$story_array[$k]->title."</a><div class='smspacer'></div>";
			$ChapterPageCount++;
			} else {
			$boxString .= "<option value='index.php?id=".$story_array[$k]->id."'";
			
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .= ">-> ".$story_array[$k]->title."</option>";
			}
			
			}
		   } else if ($PageYear == $CurrentYear) {
						if ($PageMonth<$CurrentMonth) {
							$idSafe = 1; 
							 $TotalPages++;
							if ($story_array[$k]->chapter == 1) {
			   if ($Inchapter == 1) {
			  	 $ChapterPageCount = 1;
			   }
			$boxString .= "<option style='background-color:#f6ecea;' value='index.php?id=".$story_array[$k]->id."'"; 
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .= "><b>CHAPTER </b>".$ChapterCount." - ".$story_array[$k]->title."</option>";
				$ChapterString .= "<div class='chapterlinks'><b>CHAPTER ".$ChapterCount."</b><br /><a href='index.php?id=".$story_array[$k]->id."'>".$story_array[$k]->title."</a><div class='smspacer'></div>";
			$Inchapter = 1;
			$ChapterCount++;
			} else {
			 if ($Inchapter == 1) {
			$boxString .= "<option value='index.php?id=".$story_array[$k]->id."'";
			
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .= ">&nbsp;&nbsp;&nbsp;Page ".$ChapterPageCount." - ".$story_array[$k]->title."</option>";
			$ChapterPageCount++;
			} else {
			$boxString .= "<option value='index.php?id=".$story_array[$k]->id."'";
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .= ">-> ".$story_array[$k]->title."</option>";
			}
			
			}
						   } else if ($PageMonth == $CurrentMonth) {
								    if ($PageDay<=$CurrentDay) {
									     $idSafe = 1; 
									     $TotalPages++;
				if ($story_array[$k]->chapter == 1) {
			   if ($Inchapter == 1) {
			  	 $ChapterPageCount = 1;
			   }
			$boxString .= "<option style='background-color:#f6ecea;' value='index.php?id=".$story_array[$k]->id."'";
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .="><b>CHAPTER </b>".$ChapterCount." - ".$story_array[$k]->title."</option>";
			$ChapterString .= "<div class='chapterlinks'><b>CHAPTER ".$ChapterCount."</b><br /><a href='index.php?id=".$story_array[$k]->id."'>".$story_array[$k]->title."</a><div class='smspacer'></div>";
			$Inchapter = 1;
			$ChapterCount++;
			} else {
			 if ($Inchapter == 1) {
			$boxString .= "<option value='index.php?id=".$story_array[$k]->id."'";
			
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .= ">&nbsp;&nbsp;&nbsp;Page ".$ChapterPageCount." - ".$story_array[$k]->title."</option>";
			$ChapterPageCount++;
			} else {
			$boxString .= "<option value='index.php?id=".$story_array[$k]->id."'";
			
				if ($story_array[$k]->id==$PageID) {
			$boxString .= 'selected'; 
			} 
			
			$boxString .=">-> ".$story_array[$k]->title."</option>";
			}
			
			}
				  	
			        				  } // End If
						          } // End PageMonth
			  } // end TEST
		    	if (($Active == 0) && ($idSafe = 1)){
				 $UpdateXml = 1;
   } 
} // end for
$boxString .= '</select><input type="hidden" name="url" value="index.php?id=" /> </form>';
$ChapterString .="</td></tr></table>";

if ($Width == "") {
$Width = 850;
}
if ($Height == "") {
$Height = 675;
}
if ($Width == 'undefined') {
$Width = 850;
}
if ($Height == 'undefined') {
$Height = 675;
}
if ($Width < 500) {
$Width = 500;
}

?>