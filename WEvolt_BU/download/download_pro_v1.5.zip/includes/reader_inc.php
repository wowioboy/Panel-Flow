<div id="topbar">You need to have your javascript turned on and make sure you have the latest version of Flash<a href="http://www.adobe.com/go/getflashplayer/" target="_blank">Player 9</a> or better installed.</div>
<script type="text/javascript"> 
    var so = new SWFObject('flash/topcontrols.swf','top','<?php echo $Width;?>','40','<?php echo '#'.$BGcolor;?>','9');                  so.addParam('allowfullscreen','true'); 
                  so.addParam('allowscriptaccess','true'); 
                  so.addVariable('usertype','<?php echo $_SESSION['usertype'];?>');
				  so.addVariable('backID','<?php echo $PrevPage;?>');
				  so.addVariable('nextID','<?php echo $NextPage;?>');
				  so.addVariable('currentindex','<?php echo $CurrentIndex;?>');
				  so.addVariable('totalpages','<?php echo  $TotalPages;?>');
			      so.addVariable('barcolor','<?php echo $BarColor;?>');
				  so.addVariable('textcolor','<?php echo $TextColor;?>');
				  so.addVariable('moviecolor','<?php echo $MovieColor;?>');
				  so.addVariable('buttoncolor','<?php echo $ButtonColor;?>');
				  so.addVariable('arrowcolor','<?php echo $ArrowColor;?>');
				  so.addVariable('loggedin','<?php echo $loggedin;?>');
                  so.write('topbar'); 
</script>

<div id="reader">You need to have your javascript turned on and make sure you have the latest version of Flash<a href="http://www.adobe.com/go/getflashplayer/" target="_blank">Player 9</a> or better installed.</div>

<script type="text/javascript"> 
    var so = new SWFObject('flash/pf_reader_standard_v1-4.swf','pfreader','<?php echo $Width;?>','<?php echo $Height;?>','9');             so.addParam('allowfullscreen','true'); 
                  so.addParam('allowscriptaccess','true'); 
                  so.addVariable('id','<?php echo $PageID;?>');
				  so.addVariable('currentindex','<?php echo $CurrentIndex;?>');
				  so.addVariable('pageimage','<?php echo $Image;?>');
				  so.addVariable('pagetitle','<?php echo addslashes($Title);?>');
				  so.addVariable('totalpages','<?php echo  $TotalPages;?>');
				  so.addVariable('updatexml','<?php echo  $UpdateXml;?>');
				  so.addVariable('usertype','<?php echo $_SESSION['usertype'];?>');

				  so.addVariable('barcolor','<?php echo $BarColor;?>');
				  so.addVariable('textcolor','<?php echo $TextColor;?>');
				  so.addVariable('moviecolor','<?php echo $MovieColor;?>');
				  so.addVariable('currentday','<?php echo $CurrentDay;?>');
				  so.addVariable('currentmonth','<?php echo $CurrentMonth;?>');
				  so.addVariable('currentyear','<?php echo $CurrentYear;?>');
                  so.write('reader'); 
</script>

<div id="bottombar">You need to have your javascript turned on and make sure you have the latest version of Flash<a href="http://www.adobe.com/go/getflashplayer/" target="_blank">Player 9</a> or better installed.</div>
<script type="text/javascript"> 
    var so = new SWFObject('flash/bottomcontrols.swf','bottom','<?php echo $Width;?>','40','<?php echo '#'.$BGcolor;?>','9');                  
					so.addParam('allowfullscreen','true'); 
                  so.addParam('allowscriptaccess','true'); 
                  so.addVariable('id','<?php echo $PageID;?>');
				  so.addVariable('currentindex','<?php echo $CurrentIndex;?>');
				   so.addVariable('pagetitle','<?php echo addslashes($Title);?>');
				  so.addVariable('totalpages','<?php echo  $TotalPages;?>');
				  so.addVariable('barcolor','<?php echo $BarColor;?>');
				  so.addVariable('textcolor','<?php echo $TextColor;?>');
				  so.addVariable('moviecolor','<?php echo $MovieColor;?>');
				  so.addVariable('buttoncolor','<?php echo $ButtonColor;?>');
				    so.addVariable('arrowcolor','<?php echo $ArrowColor;?>');
					so.addVariable('currentday','<?php echo $CurrentDay;?>');
				  so.addVariable('currentmonth','<?php echo $CurrentMonth;?>');
				  so.addVariable('currentyear','<?php echo $CurrentYear;?>');
                  so.write('bottombar'); 
</script>