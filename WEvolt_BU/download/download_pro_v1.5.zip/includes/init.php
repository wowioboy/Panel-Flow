<?php
 if(!isset($_SESSION)) {
    session_start();
  }  
 if (!function_exists("file_get_contents")) {
   /**
    * Reads entire file into a string
    * This function is not available in early versions of PHP 4 and it is used by FORMfields, therefore it is implemented in FORMfields.
    * @see file_get_contents
    * @since FORMfields v3.0
    */
   function file_get_contents($filename)
   {
      return implode('', file($filename));
   }
} 
$Version = '1-4 Standard';
$config = array();
include 'config.php';
$AdminUser = $config['name'];
$db_user = $config['db_user'];
$Email = $config['email'];
$ComicURL = $config['comicurl'];
$ComicID = $config['comicid'];
$CreatorID = $config['userid'];
$db_pass = $config['db_pass'];
$db_database = $config['db_database'];
$db_host = $config['db_host'];
$table = $config['table'];

// Include functions
include 'functions.php';
if ($_SESSION['email'] == $Email){
	 $_SESSION['usertype'] = '1';
} else $_SESSION['usertype'] = '0';

$PageID = $_GET['id'];
if ($PageID == "") {
$PageID = $_POST['id'];
}
if ($PageID == "undefined") {
$PageID = "";
}


if (is_authed()) { 
	$loggedin = 1;
} else {
	$loggedin = 0;
} 
?>