<?php 
for ($c=0; $c< $downloads; $c++){
	if ($DownloadItems[$c][2] == 2){
	$coverstring .= "<div class='downloadimage'><img src='".$DownloadItems[$c][5]."' width='150' height='175' border='1' style='border-color:#000000;'></div><div class='dltitle'>".$DownloadItems[$c][0]."</div><div class='dllink'><a href='".$DownloadItems[$c][4]."' target='blank'>[download]</a><div class='spacer'></div>";
	
	}
	
	}
	echo $coverstring;

?>