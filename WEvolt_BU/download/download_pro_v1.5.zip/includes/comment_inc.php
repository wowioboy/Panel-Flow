<?php 
function Comment($ComicID, $PageID, $UserID, $comment){
$Site = $_SERVER['SERVER_NAME'];
$CommentDate = date('D M j');
$querystring ='http://www.panelflow.com/processing/pfusers.php?action=pagecomment&comicid='. trim(urlencode($ComicID)).'&userid='.trim(urlencode($UserID)).'&pageid='.trim(urlencode($PageID)).'&comment='.urlencode($comment).'&site='.urlencode($Site).'&commentdate='.urlencode($CommentDate);
$commentresult = file_get_contents ($querystring);

}


function CommentProfile($CommentUser, $CommentUserID, $CreatorID, $comment, $time, $IP){
$Site = $_SERVER['SERVER_NAME'];
$querystring ='http://www.panelflow.com/processing/pfusers.php?action=profilecomment&commentuser='. urlencode($CommentUser).'&cuserid='.urlencode($CommentUserID).'&creatorid='.urlencode($CreatorID).'&comment='.urlencode($comment).'&commentdate='.urlencode($time).'&site='.urlencode($Site);
$commentresult = file_get_contents ($querystring);

$insertComment = '0';

}

function getProfileComments ($CreatorID){
$querystring ='http://www.panelflow.com/processing/pfusers.php?action=get&item=profilecomments&creatorid='.urlencode($CreatorID);

$commentsresult = file_get_contents ($querystring);

echo $commentsresult;

}


function getPageComments ($PageID, $ComicID){
$querystring ='http://www.panelflow.com/processing/pfusers.php?action=get&item=pagecomments&pageid='.urlencode($PageID).'&comicid='.urlencode($ComicID);

$commentsresult = file_get_contents ($querystring);

echo $commentsresult;

}

function getPageCommentsAdmin ($PageID, $ComicID, $UserID, $CreatorID){
$querystring ='http://www.panelflow.com/processing/pfusers.php?action=get&item=admincomments&pageid='.urlencode($PageID).'&comicid='.urlencode($ComicID).'&id='.$UserID.'&creator='.$CreatorID;
$commentsresult = file_get_contents ($querystring);

echo $commentsresult;

}


function deleteComment($ComicID, $PageID, $CommentID ,$UserID) {
$querystring ='http://www.panelflow.com/processing/pfusers.php?action=delete&item=pagecomment&pageid='.urlencode($PageID).'&comicid='.urlencode($ComicID).'&id='.$UserID.'&commentid='.$CommentID;
$commentsresult = file_get_contents ($querystring);

}
?>