<?php
  $setting = array();
  $g_elem = null;
  
  function startElement4( $parser, $name, $attrs ) 
  {
  global $setting, $g_elem;
  if ( $name == 'COMIC' )$setting []= array();
  $g_elem = $name;
  }
  
  function endElement4( $parser, $name ) 
  {
  global $g_elem;
  $g_elem = null;
  }
  
  function textData4( $parser, $text )
  {
  global $setting, $g_elem;
  if ( $g_elem == 'CONTACT' ||
  $g_elem == 'PAGECOMMENTS' ||
  $g_elem == 'ARCHIVE' ||
  $g_elem == 'CHAPTERLIST'||
  $g_elem == 'EPISODELIST'||
  $g_elem == 'CALENDAR')

  {$setting[ count($setting ) - 1 ][ $g_elem ] = $text;

  }
  }
  
  $parser = xml_parser_create();
  
  xml_set_element_handler( $parser, "startElement4", "endElement4" );
  xml_set_character_data_handler( $parser, "textData4" );
  
  $f = fopen( 'xml/settingsXML.xml', 'r' );
  
  while( $data = fread( $f, 4096 ) )
  {
  xml_parse( $parser, $data );
  }
  
  xml_parser_free( $parser );
  
  foreach($setting as $book )
  {
  if ($book['CONTACT'] != ""){
 	$ContactSetting = $book['CONTACT'];
  }
   if ($book['PAGECOMMENTS'] != ""){
  $CommentSetting = $book['PAGECOMMENTS'];
  }
   if ($book['ARCHIVE'] != ""){
    $ArchiveSetting = $book['ARCHIVE'];
  }
  if ($book['CHAPTERLIST'] != ""){
  $ChapterSetting = $book['CHAPTERLIST'];
  }
  if ($book['EPISODELIST'] != ""){
  $EpisodeSetting = $book['EPISODELIST'];
  }
  if ($book['CALENDAR'] != ""){
  $CalendarSetting = $book['CALENDAR'];
  }
  }

  ?>