<?php
  $linkarray = array();
  $rec_elem = null;
  
  function startElement2( $parser, $name, $attrs ) 
  {
  global $linkarray, $rec_elem;
  if ( $name == 'LINKITEM' )$linkarray []= array();
  $rec_elem = $name;
  }
  
  function endElement2( $parser, $name ) 
  {
  global $rec_elem;
  $rec_elem = null;
  }
  
  function textData2( $parser, $text )
  {
  global $linkarray, $rec_elem;
  if ( $rec_elem == 'TITLE' ||
  $rec_elem == 'LINK' ||
  $rec_elem == 'SYNOPSIS')
  {
  $Links = '1';
  $linkarray[ count($linkarray ) - 1 ][ $rec_elem ] = $text;
  }
  }
  
  $parser = xml_parser_create();
  
  xml_set_element_handler( $parser, "startElement2", "endElement2" );
  xml_set_character_data_handler( $parser, "textData2" );
  
  $f = fopen( 'xml/linksXML.xml', 'r' );
  
  while( $data = fread( $f, 4096 ) )
  {
  xml_parse( $parser, $data );
  }

  xml_parser_free( $parser );

  $linkstring = '';
  	foreach($linkarray as $linkitem) {
	$linkstring .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'><tr>
    <td valign='middle'></td>
    <td width='50%' valign='top' class='rectitle'><a href='".$linkitem['LINK']."' target='blank'>".$linkitem['TITLE']."</a></td><td width='49%' valign='top' class='recdescription'>".$linkitem['SYNOPSIS']."</td>
  </tr></table><div class='spacer'></div>";
  }
    
?>