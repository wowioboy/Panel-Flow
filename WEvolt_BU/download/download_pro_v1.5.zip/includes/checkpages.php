<? 
$pageresult = file_get_contents ('http://www.panelflow.com/processing/updatecomic.php?action=getpages&comicid='.$ComicID);
$Remote = $_SERVER['REMOTE_ADDR'];
$ID = $_SESSION['userid'];
file_get_contents ('http://www.panelflow.com/processing/updatecomic.php?action=tracking&comicid='.$ComicID.'&page='.$Pagetracking.'&remote='.$Remote.'&id='.$ID);
if ($pageresult != $TotalPages) {
$result = file_get_contents ('http://www.panelflow.com/processing/updatecomic.php?action=pages&userid='.$CreatorID."&comicid=".$ComicID."&pages=".$TotalPages);
}

?>
