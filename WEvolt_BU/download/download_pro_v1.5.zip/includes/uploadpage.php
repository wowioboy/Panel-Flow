<?php
//create the directory if doesn't exists (should have write permissons)
if(!is_dir("../images/pages")) mkdir("../images/pages", 0755); 
//move the uploaded file

move_uploaded_file($_FILES['Filedata']['tmp_name'], "../images/pages/". $_FILES['Filedata']['name']);
chmod("../images/pages/". $_FILES['Filedata']['name'], 0777);
?>

