<?php 
include 'favorites_inc.php'; 
include 'settings_inc.php';
include 'comment_inc.php';
include 'links_inc.php';
include 'comicinfo.php';
include 'creatorinfo.php';
include 'parser.php'; 
include 'datecheck.php'; 
include 'checkpages.php'; 

$Avatar = GetAvatar($CreatorID);
$Links = '0';
$insertComment = $_POST['insert'];
$DeleteComment = $_POST['deletecomment'];
$ProfileComment = $_POST['profilecomment'];

//INSERT POFILE COMMENT
if ($ProfileComment == '1'){
CommentProfile($_SESSION['username'], $_SESSION['userid'], $CreatorID, $_POST['txtFeedback'], date('D M j'), $_SERVER['REMOTE_ADDR']);
} 

//DELETE COMMENT
if ($DeleteComment == '1'){
deleteComment($ComicID, $_GET['id'], $_POST['commentid'],trim($_SESSION['userid']));
}

//INSERT PAGE COMMENT
if ($insertComment == '1'){
Comment($ComicID, $_GET['id'], trim($_SESSION['userid']), $_POST['txtFeedback']);
}

//ADD FAV
if ($_POST['addfav'] == 1) {
addfavorite($ComicID, $CreatorID, trim($_SESSION['userid']));
}
?>