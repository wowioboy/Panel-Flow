<?php
  $page = array();
  $tag = null;
  $l = 0;
  
  function startElement2( $parser, $tagname, $attrs ) 
  {
  global $page, $tag;
  if ( $tagname == 'PAGE' ) $page []= array();
  $tag = $tagname;
  }
  
  function endElement2( $parser, $tagname ) 
  {
  global $tag;
  $tag = null;
  }
  
  function textData2( $parser, $text )
  {
  global $page, $tag;
  if ( $tag == 'ID' ||
  $tag == 'TITLE' ||
  $tag == 'COMMENT'||
  $tag == 'IMAGE'||
  $tag == 'IMGHEIGHT' ||
  $tag == 'ACTIVE'||
  $tag == 'DATELIVE') 
  
  {
  $page[ count( $page ) - 1 ][ $tag ] = $text;
  }
  }
  
  $parser = xml_parser_create();
  
  xml_set_element_handler( $parser, "startElement2", "endElement2" );
  xml_set_character_data_handler( $parser, "textData2" );
  
  $f = fopen( 'xml/pageXML.xml', 'r' );
  
  while( $data = fread( $f, 4096 ) )
  {
  xml_parse( $parser, $data );
  }
  
  xml_parser_free( $parser );

  
  ?>