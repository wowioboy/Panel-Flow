<?php
include 'init.php';
$result = file_get_contents ('http://www.panelflow.com/processing/updatecomic.php?action=info&userid='.$_GET['userid']."&comicid=".$ComicID);
?>