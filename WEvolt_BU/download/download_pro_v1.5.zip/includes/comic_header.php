<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<script type="text/javascript" src="scripts/swfobject.js"></script>
<meta name="description" content="<?php echo $Synopsis ?>"></meta>
<meta name="keywords" content="Panel Flow, Flash Webcomic Content Management System, <?php echo $Genre;?>, <?php echo $Tags;?>, <?php echo $Creator;?>, <?php echo $Writer;?>, <?php echo $Letterist;?>, <?php echo $Artist;?>, <?php echo $Colorist;?>"></meta>
<LINK href="css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $ComicTitle; ?> - <?php echo $Title; ?></title>
</head>
<? $Text = substr($TextColor, 2, 6); ?>
<body bgcolor="<?php echo '#'.$BGcolor;?>" style="color:#<? echo $Text; ?>;">

<div class="wrapper" align="center">

<? if ($HeaderImage != "" ) {?><div class="header"><img src="<?php echo $HeaderImage;?>" /></div><? }?>
