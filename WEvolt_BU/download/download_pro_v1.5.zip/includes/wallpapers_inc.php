<?php 
for ($z=0; $z< $downloads; $z++){
	if ($DownloadItems[$z][2] == 1){
	$wallstring .= "<div class='downloadimage'><img src='".$DownloadItems[$z][5]."' width='200' height='150' border='1' style='border-color:#000000;'></div><div class='dltitle'>".$DownloadItems[$z][0]."</div><div class='dllink'><a href='".$DownloadItems[$z][4]."' target='blank'>[download]</a><div class='spacer'></div>";
	
	}
	
	}
	echo $wallstring;

?>