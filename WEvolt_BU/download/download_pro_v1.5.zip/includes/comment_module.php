<?php if (is_authed()) { ?>

	 <div class="authornote"><img src="images/radiobtn.jpg" />LEAVE A COMMENT</div>

	<form method="POST" action="index.php?id=<?php echo $PageID; ?>">
	<textarea rows="5" style="width:100%" name="txtFeedback" id="txtFeedback"></textarea>
	<input type="hidden" name="insert" id="insert" value="1">
	<input type="hidden" name="userid" id="userid" value="<?php echo $_SESSION['userid']; ?>">
	<input type="hidden" name="id" id="id" value="<?php echo $PageID; ?>"><div class="spacer"></div>
	<input type="image" value="Submit Comment" src="../images/submit.jpg" style="border:none;" />&nbsp;&nbsp;<a href="logout.php"><img src="../images/logout_btn.jpg" border="0" /></a>
	</form>
	<div class="spacer"></div>
	
	
<?php } else { ?> 

<div class="authornote" align="center">YOU NEED TO LOG IN TO LEAVE COMMENTS </div>
<?php }?>