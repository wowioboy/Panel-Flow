<?php 
$avatarstring = "<table width ='100%' cellspacing='0' cellpadding='0' border='0' margin ='0'><tr>";
$avatarcnt = 0;
for ($a=0; $a< $downloads; $a++){
	if ($DownloadItems[$a][2] == 3){
$avatarstring .= "<td width ='100'><div class='downloadimage'><img src='".$DownloadItems[$a][5]."' width='100' height='100' border='1' style='border-color:#000000;'></div><div class='dltitle'>".$DownloadItems[$a][0]."</div><div class='dllink'><a href='".$DownloadItems[$a][4]."' target='blank'>[download]</a><div class='spacer'></div></td>";
	 $avatarcnt++;
 if ($avatarcnt == 2){
 $avatarstring .= "</tr><tr>";
 $avatarcnt = 0;
 }
	}
	
	}
	 $avatarstring .= "</table>";
	echo $avatarstring;

?>