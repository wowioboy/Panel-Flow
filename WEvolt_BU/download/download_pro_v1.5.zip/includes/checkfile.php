<?php 

$Filename = $_POST['txtFilename']; 
$Section = $_POST['txtSection'];

if ($Section == 'extras') {
$link = '../images/extras/'.$Filename;
} else {
$link = '../images/pages/'.$Filename;
}

if (file_exists($link)) {
    echo '&fileresult=Found';
} else {
    echo '&fileresult=Not found';
}

?>