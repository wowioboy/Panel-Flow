</div>	
<div class="legal"><?php echo $Copyright ?> </div>	
</body>
</html>
