<div align="left">
<div class="authornote"><img src="images/radiobtn.jpg" />COMMENTS:</div>
<div class="spacer"></div><div class="commentwrapper" style="padding-left:10px;">

<?php 
if ($_SESSION['usertype'] == 1){
	$PageComments = getPageCommentsAdmin ($PageID, $ComicID, trim($_SESSION['userid']), $CreatorID);
} else {
$PageComments = getPageComments ($PageID, $ComicID);}

echo $PageComments;?></div>
</div>		