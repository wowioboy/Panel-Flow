<div class="rightwrapper"> 
	 <div class="authornote"><img src="images/radiobtn.jpg" />SYNOPSIS: </div>
	 <div class="comiccredits" style="padding-left:10px;"><div class="halfspacer"></div>
	<?php if (isset($Synopsis)) { ?>
			
			<div class="infotext"><?php echo stripslashes($Synopsis); ?></div>
	<?php } ?>	

	</div>	
	</div>