<?php include 'includes/init.php';?>
<?php 
if (isset($_POST['email'])) {
$logresult = file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=logincrypt&email='.$_POST['email'].'&pass='.md5($_POST['userpass']));
     if ((trim($logresult) != 'Not Logged') && (trim($logresult) != 'Not Verified')) 
     {
	 $_SESSION['userid'] = trim($logresult);
     $Useremail = $_POST['email']; 
	 $_SESSION['email'] = $Useremail;
	 $_SESSION['encrypted_email'] =  md5($Useremail);
	 
$getUser = file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=get&item=username&id='.$_SESSION['userid']);
$_SESSION['username'] = $getUser;
$getUser = file_get_contents ('http://www.panelflow.com/processing/pfusers.php?action=get&item=avatar&id='.$_SESSION['userid']);
 	   $_SESSION['avatar'] = $getUser;
	    if ($ReturnPage == '')
      header('Location: index.php');
      else
      header('Location: ' . $ReturnPage);
 } else if (trim($logresult) == 'Not Logged') { $login_error = "Could Not Log into Account. Please check your fields and try again.";
} else if (trim($logresult) == 'Not Verified') { $login_error = "<div style='padding-left:15px; padding-right:15px;'>You have not yet verified your account, please click the link that was sent to your email that you registered with. If you have not recieved the email, please goto: <a href='http://www.panelflow.com/resend.php' target='blank'>www.panelflow.com/resend.php</a></div>";
} 
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<LINK href="http://www.panelflow.com/css/pf_css.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PANEL FLOW - USER LOGIN</title>
</head>

<body>
<?php include 'includes/header.php'; ?>

<?php 
include 'includes/login_form.inc.php';
?>
<?php include 'includes/footer.php'; ?>