<div class="leftwrapper">
<div class="authornote"><img src="/<? echo $PFDIRECTORY;?>/templates/<? echo $TEMPLATE;?>/images/radiobtn.jpg" />AUTHOR COMMENT:</div>
<div class="infotext" style="padding-left:10px;">posted: <?php echo $Date;?></div>
<div class="notespacer"></div>
<div class="infotext" style="padding-left:10px;"><table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td align="justify" valign="top" ><b><? echo $CreatorName;?></b><br />
<img src="<? echo $Avatar; ?>" border="2" align="left" hspace="4" vspace="2"/><?php echo nl2br(stripslashes($AuthorComment));?></td>
</tr></table></div>	
</div>	