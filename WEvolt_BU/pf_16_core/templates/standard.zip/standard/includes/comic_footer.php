</div>	
<div class="legal">All Content &copy; <?php echo $Copyright ?> </div>	
</body>
</html>
