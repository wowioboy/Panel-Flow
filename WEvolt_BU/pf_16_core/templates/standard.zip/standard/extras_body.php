<?php 
	// Comic Header
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/comic_header.php';?>

<?php 
//PANEL FLOW READER
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/common/includes/reader_inc.php';?>
				
<div class="spacer"></div>	
<div class="contentwrapper" align="center">

<table width="706">
<tr>
<td width="340" height="229" valign="top">
	
<!-- AUTHOR COMMENT MODULE -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop"></td>
	<td id="modtopright"></td>
</tr>
	
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	<?php 
	//AUTHOR COMMENT MODULE
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/author_comment_module.php';?>

	</td>
	<td id="modrightside"></td>
</tr>
	
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->
<? if ($CommentSetting == 1) { ?>
<!-- PAGE COMMENT MODULE -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop"></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
	
		<?php 
	// Page Comments Module
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/page_comments_module.php';?>
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->		
<? } ?>
</td>	
<!-- END OF LEFT COLUM  -->		
<td width="10">&nbsp;</td>		
<td width="340" valign="top">

<!-- USER CONTROL MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
				
		<?php 
	// User Control Module
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/common/includes/user_module.php';?>	
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td  id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->
		

<!-- COMIC INFO MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td width="318" id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
		<?php 
	// Comic Info Module
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/comic_module.php';?>
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->

<!-- COMIC SYNOPSIS MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td id="modtop" ></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
		<?php 
	// Synopsis Module
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/comic_synopsis_module.php';?>				
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->
<? if ($CommentSetting == 1) { ?>
<!-- COMMENT FORM MODULE  -->
<table width="340" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td id="modtopleft"></td>
	<td id="modtop"></td>
	<td id="modtopright"></td>
</tr>
<tr>
	<td id="modleftside"></td>
	<td class="boxcontent" width="318" valign="top">	
		<?php 
	//Comments Module
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/comment_module.php';?>			
	</td>
	<td id="modrightside"></td>
</tr>
<tr>
	<td id="modbottomleft"></td>
	<td id="modbottom"></td>
	<td id="modbottomright"></td>
</tr>
</table>
<!-- END MODULE  -->
<? } ?>
<!-- USER LOGIN MODULE  -->

	<?php 
	// Login Module
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/common/includes/login_inc.php';?>
	
<!-- END MODULE  -->
		
</td>
</tr>
</table>
</div>			
	<?php 
	// Comic Footer
include str_repeat('../', $calling_dist - $include_dist + 1).$PFDIRECTORY.'/templates/'.$TEMPLATE.'/includes/comic_footer.php';?>